  <!-- footer start -->

  <footer id="dk-footer" class="dk-footer text-dark">
      <div class="container-xl py-4">
          <div class="row g-3">

              <div class="dk-footer-box-info  col-lg-4 col-md-4 col-sm-10">
                  <a href="index.html" class="footer-logo py-2">
                      <img src="img/seacosoft_logo_foot.png" alt="footer_logo" class="col-3">
                  </a>
                  <p class="footer-info-text text-light">
                      Lorem Ipsum, giving information on its origins,
                      Lipsum generator.
                  </p>
                  <div class="row">
                      <div class="col-md-12 col-sm-10">
                          <div class="contact-us">
                              <div class="contact-icon">
                                  <i class="fa-solid fa-map"></i>
                              </div>
                              <!-- End contact Icon -->
                              <div class="contact-info">
                                  <h3>Noida, India</h3>
                                  <p>H-15 Sector-63</p>
                              </div>
                              <!-- End Contact Info -->
                          </div>
                          <!-- End Contact Us -->
                      </div>
                      <!-- End Col -->
                      <div class="col-md-12 col-sm-10">
                          <div class="contact-us contact-us-last">
                              <div class="contact-icon">
                                  <i class="fa fa-volume-control-phone" aria-hidden="true"></i>
                              </div>
                              <!-- End contact Icon -->
                              <div class="contact-info">
                                  <h3>1234567890</h3>
                                  <p>Give us a call</p>
                              </div>
                              <!-- End Contact Info -->
                          </div>
                          <!-- End Contact Us -->
                      </div>
                      <!-- End Col -->
                  </div>

                  <!-- End Social link -->
              </div>
              <!-- End Footer info -->
              <!-- End Col -->
              <div class="col-md-8 col-lg-8 col-sm-10">

                  <!-- End Contact Row -->
                  <div class="row">
                      <div class="col-md-6 col-lg-6 col-sm-10">
                          <div class="footer-widget footer-left-widget">
                              <div class="section-head">
                                  <h3>Useful Links</h3>
                                  <span class="animate-border border-black"></span>
                              </div>
                              <ul class="mt-3">
                                  <li>
                                      <a href="index.php">Home</a>
                                  </li>
                                  <li>
                                      <a href="about-us.php">About us</a>
                                  </li>
                                  <li>
                                      <a href="service.php">Services</a>
                                  </li>
                              </ul>
                              <ul class="mt-3">
                                  <li>
                                      <a href="portfolio.php">Portfolio</a>
                                  </li>
                                  <li>
                                      <a href="contact-us.php">Contact us</a>
                                  </li>
                              </ul>
                          </div>
                          <!-- End Footer Widget -->
                          <div class="footer-social-link py-2">
                              <h3>Follow us</h3>
                              <ul>
                                  <li>
                                      <a href="#">
                                          <i class="fa-brands fa-facebook"></i></a>

                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa-brands fa-linkedin"></i>
                                      </a>

                                  </li>

                                  <li>
                                      <a href="#">
                                          <i class="fa-brands fa-x-twitter"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa-brands fa-instagram"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <!-- End col -->
                      <div class="col-md-6 col-lg-6 col-sm-10">
                          <div class="footer-widget">
                              <div class="section-head">
                                  <h3>Subscribe</h3>
                                  <span class="animate-border border-black"></span>
                              </div>
                              <p class="text-light"><!-- Don’t miss to subscribe to our new feeds, kindly fill the form below. -->
                                  Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                              <form action="#">
                                  <div class="form-row">
                                      <div class=" dk-footer-form">
                                          <input type="email" class="form-control" placeholder="Email Address">
                                          <button type="submit">
                                              <i class="fa-regular fa-paper-plane"></i>
                                          </button>
                                      </div>
                                  </div>
                              </form>
                              <!-- End form -->
                          </div>
                          <!-- End footer widget -->
                      </div>
                      <!-- End Col -->
                  </div>
                  <!-- End Row -->
              </div>
              <!-- End Col -->
          </div>
          <!-- End Widget Row -->
      </div>
      <!-- End Contact Container -->


      <!-- <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span>Copyright © 2019, All Right Reserved Seobin</span>
                </div>
            </div>
        
        </div>
    
    </div> -->


  </footer>
